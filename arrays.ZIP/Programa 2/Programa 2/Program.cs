﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_2
{
    class Program
    {
        static void Main(string[] args)
        {
            float[] num = new float[5];
            Console.WriteLine("Deme 5 numeros diferentes y se los mostraré en el orden inverso al que usted los puso: ");
            Console.WriteLine("Introducir el primer numero: ");
            num[0] = float.Parse(Console.ReadLine());

            Console.WriteLine("Introducir el segundo numero: ");
            num[1] = float.Parse(Console.ReadLine());
            
            Console.WriteLine("Introducir el tercer numero: ");
            num[2] = float.Parse(Console.ReadLine());
            
            Console.WriteLine("Introducit el cuarto numero: ");
            num[3] = float.Parse(Console.ReadLine());
            
            Console.WriteLine("Introducir el quinto y ultimo numero: ");
            num[4] = float.Parse(Console.ReadLine());
            
            Console.WriteLine("El orden inverso es: " + num[4] + ", " + num[3] + ", " + num[2] + ", " + num[1] + "," + num[0]);
            Console.ReadKey();
        }
    }
}
