﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] var_1 = new int[4];
            int media;
            Console.WriteLine("A continuacion deme 4 numeros:");
            Console.WriteLine("Dime el primero de ellos: ");
            var_1[0] = int.Parse(Console.ReadLine());
            Console.WriteLine("Ahora el segundo:");
            var_1[1] = int.Parse(Console.ReadLine());
            Console.WriteLine("Ahora el tercero:");
            var_1[2] = int.Parse(Console.ReadLine());
            Console.WriteLine("Y ahora el cuarto:");
            var_1[3] = int.Parse(Console.ReadLine());
            media = (var_1[0] + var_1[1] + var_1[2] + var_1[3]) / 4;
            Console.WriteLine("La media de sus numeros es: " + media + " y los numeros introducidos fueron: " + var_1[0] + ", " + var_1[1] + ", " + var_1[2] + ", " + var_1[3]);
            Console.ReadKey();
        }
    }
}
