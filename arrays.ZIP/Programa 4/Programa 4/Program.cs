﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[10];
            Console.WriteLine("Por favor introduzca 10 numeros y le diré cual es el mayor de todos: ");

            Console.WriteLine("El primer numero: ");
            num[0] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El segundo numero: ");
            num[1] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El tercer numero:  ");
            num[2] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El cuarto numero: ");
            num[3] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El quinto numero:  ");
            num[4] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El sexto numero:  ");
            num[5] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El septimo numero:  ");
            num[6] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El octavo numero:  ");
            num[7] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El noveno numero:  ");
            num[8] = int.Parse(Console.ReadLine());
            
            Console.WriteLine("El decimo y ultimo numero:  ");
            num[9] = int.Parse(Console.ReadLine());

            if ((num[0] > num[1]) && (num[0] > num[2]) && (num[0] > num[3]) && (num[0] > num[4]) && (num[0] > num[5]) && (num[0] > num[6]) && (num[0] > num[7]) && (num[0] > num[8]) && (num[0] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[0]);
            }
            else if ((num[1] > num[0]) && (num[1] > num[2]) && (num[1] > num[3]) && (num[1] > num[4]) && (num[1] > num[5]) && (num[1] > num[6]) && (num[1] > num[7]) && (num[1] > num[8]) && (num[1] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[1]);
            }
            else if ((num[2] > num[0]) && (num[2] > num[1]) && (num[2] > num[3]) && (num[2] > num[4]) && (num[2] > num[5]) && (num[2] > num[6]) && (num[2] > num[7]) && (num[2] > num[8]) && (num[2] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[2]);
            }
            else if ((num[3] > num[0]) && (num[3] > num[1]) && (num[3] > num[2]) && (num[3] > num[4]) && (num[3] > num[5]) && (num[3] > num[6]) && (num[3] > num[7]) && (num[3] > num[8]) && (num[3] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[3]);
            }
            else if ((num[4] > num[0]) && (num[4] > num[1]) && (num[4] > num[2]) && (num[4] > num[3]) && (num[4] > num[5]) && (num[4] > num[6]) && (num[4] > num[7]) && (num[4] > num[8]) && (num[4] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[4]);
            }
            else if ((num[5] > num[0]) && (num[5] > num[1]) && (num[5] > num[2]) && (num[5] > num[3]) && (num[5] > num[4]) && (num[5] > num[6]) && (num[5] > num[7]) && (num[5] > num[8]) && (num[5] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[5]);
            }
            else if ((num[6] > num[0]) && (num[6] > num[1]) && (num[6] > num[2]) && (num[6] > num[3]) && (num[6] > num[4]) && (num[6] > num[5]) && (num[6] > num[7]) && (num[6] > num[8]) && (num[6] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[6]);
            }
            else if ((num[7] > num[0]) && (num[7] > num[1]) && (num[7] > num[2]) && (num[7] > num[3]) && (num[7] > num[4]) && (num[7] > num[5]) && (num[7] > num[6]) && (num[7] > num[8]) && (num[7] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[7]);
            }
            else if ((num[8] > num[0]) && (num[8] > num[1]) && (num[8] > num[2]) && (num[8] > num[3]) && (num[8] > num[4]) && (num[8] > num[5]) && (num[8] > num[6]) && (num[8] > num[7]) && (num[8] > num[9]))
            {
                Console.WriteLine("El numero mayor es: " + num[8]);
            }
            else
            {
                Console.WriteLine("El numero mayor es: " + num[9]);
            }
            Console.ReadKey();





        }
    }
}
