﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] dia = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            int mes;
            Console.WriteLine("Introducir el mes del 1 al 12:");
            mes = int.Parse(Console.ReadLine());
            if (mes == 1)
            {
                Console.WriteLine("Ese mes es Enero y este tiene: " + dia[0] + " dias");
            }
            else if (mes == 2)
            {
                Console.WriteLine("Ese mes es Febrero y este tiene: " + dia[1] + " dias");
            }
            else if (mes == 3)
            {
                Console.WriteLine("Ese mes es Marzo y este tiene: " + dia[2] + " dias");
            }
            else if (mes == 4)
            {
                Console.WriteLine("Ese mes es Abril y este tiene: " + dia[3] + " dias" );
            }
            else if (mes == 5)
            {
                Console.WriteLine("Ese mes es Mayoy este tiene: " + dia[4] + " dias");
            }
            else if (mes == 6)
            {
                Console.WriteLine("Ese mes es Junioy este tiene: " + dia[5] + " dias");
            }
            else if (mes == 7)
            {
                Console.WriteLine("Ese mes es Julio y este tiene: " + dia[6] + " dias");
            }
            else if (mes == 8)
            {
                Console.WriteLine("Ese mes es Agosto y este tiene: " + dia[7] + " dias");
            }
            else if (mes == 9)
            {
                Console.WriteLine("Ese mes es Septiembre y este tiene: " + dia[8] + " dias");
            }
            else if (mes == 10)
            {
                Console.WriteLine("Ese mes es Octubre y este tiene: " + dia[9] + " dias");
            }
            else if (mes == 11)
            {
                Console.WriteLine("Ese mes es Noviembre y este tiene: " + dia[10] + " dias");
            }
            else if (mes == 12)
            {
                Console.WriteLine("Ese mes es Diciembre y este tiene: " + dia[11] + " dias");
            }
            else
            {
                Console.WriteLine("Por favor un numero del 1 al doce.");
            }
            Console.ReadKey();




        }
    }
}
